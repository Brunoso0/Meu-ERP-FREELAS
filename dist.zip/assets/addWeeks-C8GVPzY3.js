import{a7 as o}from"./index-DgX5weKT.js";function t(a,s){const d=s*7;return o(a,d)}export{t as a};
