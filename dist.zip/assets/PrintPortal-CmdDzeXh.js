import{a3 as o,j as r}from"./index-DgX5weKT.js";function s({children:t}){return o.createPortal(r.jsx("div",{className:"pdoc-print-root",children:t}),document.body)}export{s as P};
