import{c,a0 as g,J as L,a1 as N,r as j,a as n,j as t,S as b,E as S,L as E,P as M,w as i,Z as F,B as V,Q as w}from"./index-DgX5weKT.js";import{P as D}from"./PrintPortal-CmdDzeXh.js";import{P as k}from"./ProposalDocument-QafsNTaf.js";import{b as H}from"./proposal-BNvT0Zbs.js";/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const T=c("ArrowLeft",[["path",{d:"m12 19-7-7 7-7",key:"1l729n"}],["path",{d:"M19 12H5",key:"x3x0zl"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const B=c("FileQuestion",[["path",{d:"M12 17h.01",key:"p32p05"}],["path",{d:"M15 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V7z",key:"1mlx9k"}],["path",{d:"M9.1 9a3 3 0 0 1 5.82 1c0 2-3 3-3 3",key:"mhlwft"}]]);/**
 * @license lucide-react v0.460.0 - ISC
 *
 * This source code is licensed under the ISC license.
 * See the LICENSE file in the root directory of this source tree.
 */const C=c("Printer",[["path",{d:"M6 18H4a2 2 0 0 1-2-2v-5a2 2 0 0 1 2-2h16a2 2 0 0 1 2 2v5a2 2 0 0 1-2 2h-2",key:"143wyd"}],["path",{d:"M6 9V3a1 1 0 0 1 1-1h10a1 1 0 0 1 1 1v6",key:"1itne7"}],["rect",{x:"6",y:"14",width:"12",height:"8",rx:"1",key:"1ue0tg"}]]),P=()=>document.fonts.ready.then(()=>window.print());function A(){var x,u,h,f;const{id:v}=g(),l=L(),d=((x=N().state)==null?void 0:x.print)===!0,p=j.useRef(!1),e=n("proposals"),o=n("clients"),y=(u=n("profiles").data)==null?void 0:u[0],a=(h=e.data)==null?void 0:h.find(s=>s.id===v),m=!e.isLoading&&!o.isLoading&&!!a;if(j.useEffect(()=>{if(!d||!m||p.current)return;const s=setTimeout(()=>{p.current=!0,P()},400);return()=>clearTimeout(s)},[d,m]),e.isLoading||o.isLoading)return t.jsx(b,{className:"mx-auto h-[70vh] w-full max-w-[794px]"});if(!a)return t.jsx(S,{icon:B,title:"Proposta não encontrada",description:"Ela pode ter sido excluída.",action:t.jsx(E,{to:"/propostas",className:"text-sm font-medium text-brand-600 hover:underline dark:text-brand-400",children:"Voltar para propostas"})});const r=H(a,(f=o.data)==null?void 0:f.find(s=>s.id===a.client_id),y);return t.jsxs("div",{className:"mx-auto max-w-[794px]",children:[t.jsx(M,{title:r.number,description:a.title,actions:t.jsxs(t.Fragment,{children:[t.jsxs(i,{variant:"ghost",onClick:()=>l("/propostas"),children:[t.jsx(T,{className:"h-4 w-4"})," Voltar"]}),a.status==="approved"&&t.jsxs(i,{variant:"secondary",onClick:()=>l("/ferramentas/contrato",{state:{proposalId:a.id}}),children:[t.jsx(F,{className:"h-4 w-4"})," Gerar contrato"]}),t.jsxs(i,{onClick:P,children:[t.jsx(C,{className:"h-4 w-4"})," Salvar em PDF / Imprimir"]})]})}),t.jsxs("div",{className:"no-print mb-4 flex flex-wrap items-center gap-3",children:[t.jsx(V,{tone:w[a.status].tone,children:w[a.status].label}),t.jsx("span",{className:"text-xs text-slate-500 dark:text-slate-400",children:'Na janela de impressão, escolha "Salvar como PDF" como destino.'})]}),t.jsx(k,{doc:r}),t.jsx(D,{children:t.jsx(k,{doc:r})})]})}export{A as default};
