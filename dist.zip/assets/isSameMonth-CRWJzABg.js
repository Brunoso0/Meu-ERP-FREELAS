import{ac as o}from"./index-DgX5weKT.js";function g(a,n){const t=o(a),e=o(n);return t.getFullYear()===e.getFullYear()&&t.getMonth()===e.getMonth()}export{g as i};
